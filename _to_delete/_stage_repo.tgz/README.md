# Hujjat OCR va avtomatik to'ldirish tizimi

Pasport, ID karta va diplom rasmidan ma'lumot chiqarib, Word shablonlarini
avtomatik to'ldiradigan tizim.

```
Rasm  →  Preprocessing  →  L0 MRZ  →  L1 Qoidalar  →  L2 LLM(matn)  →  L3 VLM(rasm)
                                ↓
                    Kanonik sxema (Person / Education)
                                ↓
                    Word shabloni (Jinja2)  →  DOCX / PDF
```

## Loyihaning asosiy qarorlari

**MRZ birinchi, model keyin.** Pasport va ID kartadagi mashina o'qiydigan zona
ICAO 9303 standarti bo'yicha check digit bilan himoyalangan. Bu OCR xatosini
nafaqat *aniqlash*, ko'pincha *tuzatish* imkonini beradi. Shu sabab hujjat
raqami, sanalar, jins, fuqarolik va JSHSHIR arifmetik tasdiq bilan olinadi —
hech qanday model bunga yeta olmaydi.

**LLM rasmni emas, matnni ko'radi.** L2 bosqichi lokal OCR chiqargan
*matnni* yuboradi. Uch foyda: hujjat rasmi serverdan chiqmaydi, token soni
~5 barobar kamayadi, va tekshiruv arzimas darajada oson bo'ladi — model
qaytargan har bir qiymat o'sha matnda mavjud bo'lishi shart.

**Hech narsa taxmin qilinmaydi.** O'qilmagan maydon `None` bo'ladi va ko'rib
chiqishga yuboriladi. Bo'sh maydon noto'g'ri maydondan doim yaxshiroq.

## Isbotlangan xavfsizlik xususiyatlari

Bular hujjatdagi va'da emas, testlar bilan ta'minlangan invariantlar:

| Xususiyat | Qayerda tekshiriladi |
|---|---|
| Tasdiqlangan deb belgilangan qiymat hech qachon xato emas | `test_mrz.py::TestNeverSilentlyWrong` |
| Bepul LLM tier'ga real shaxsiy ma'lumot ketmaydi | `test_llm_layer.py::TestPIIGate` |
| Model o'ylab topgan qiymat rad etiladi | `test_llm_layer.py::TestGrounding` |
| Shablon orqali kod bajarilmaydi (SSTI) | `test_docgen.py::TestSandboxSSTI` |
| Log'larda shaxsiy ma'lumot qolmaydi | `test_security.py::TestRedaction` |
| Shifrlanmagan PII bazaga yozilmaydi | `test_security.py::TestCrypto` |

Bularning har biri CI'da alohida darvoza sifatida ishlaydi.

### Nima uchun "tasdiqlash" alohida ehtiyot talab qiladi

Mod-10 check digit bitta o'nlik raqamni tashiydi, ya'ni tasodifiy
almashtirishlarning ~10% i tasodifan to'g'ri check digit beradi. Boshlang'ich
tuzatish algoritmi shu sabab **360 holatdan 179 tasida xato qiymatni
"tasdiqlangan"** deb belgilagan edi.

Hozirgi qoida: tahrir isbot emas. Faqat quyidagilar tasdiqlanadi:

- o'qilgan qiymatning o'zi check digit'ga mos (`edits == 0`), yoki
- tahrirni mustaqil dalil tasdiqlagan: OCR o'sha pozitsiyani ishonchsiz deb
  belgilagan, yoki bir necha maydonni qamrab oluvchi composite check digit
  aynan shu kombinatsiyani tasdiqlagan

Tasdiqlanmagan tuzatishda foydalanuvchiga **hujjatda yozilgan qiymat**
ko'rsatiladi, taklif esa `alternatives` sifatida beriladi. Jimgina
almashtirilgan hujjat raqami — ishonarli ko'rinadi va shuning uchun
tekshirishdan o'tib ketadi.

## Ishga tushirish

```bash
make env      # .env yaratadi va maxfiy so'zlarni generatsiya qiladi
make dev      # api, ml-service, db, storage, web
make test     # virtualenv yaratib, 188 testni ishga tushiradi
```

`make dev` LibreOffice'ni qurmaydi — u ~400 MB va build'ni bir necha daqiqaga
cho'zadi. U faqat `.doc` shablonlarni o'girish va PDF chiqishi uchun kerak:

```bash
make dev-full     # converter bilan birga
```

`make env` uchta maxfiy so'zni generatsiya qiladi (`ENCRYPTION_KEY`,
`JWT_SECRET`, `INTERNAL_TOKEN`) va `.env` ichiga **o'rniga yozadi** — oxiriga
qo'shmaydi. Ikki marta ishga tushirsangiz mavjudlariga tegmaydi.

Birinchi `make dev` 5-10 daqiqa oladi (LibreOffice ~400 MB, npm install).
Keyingi safar layer cache tufayli tez bo'ladi.

Muammo chiqsa: **`TROUBLESHOOTING.md`**

Frontend `localhost:3000`, API `localhost:8000/docs`.

## Struktura

```
packages/schema     kanonik modellar, MRZ validatorlari, transliteratsiya
packages/ml         preprocessing, MRZ, qoidalar, kaskad orkestratori
packages/llm        provayder abstraksiyasi, PII darvozasi, grounding
packages/docgen     run coalescing, sanitizatsiya, Word render
apps/api            FastAPI backend
apps/ml-service     ONNX inference (PyTorch yo'q)
apps/converter      LibreOffice mikroservisi
apps/web            Next.js
training/           Colab notebook (sintetik dataset)
eval/               golden set va baholash
```

## LLM kalitlari

`.env` da uch xil kalit turi bor va ular teng emas:

| Kalit | Real PII | Nima uchun |
|---|---|---|
| `OPENAI_API_KEY` (pullik) | ✅ | Yuborilgan ma'lumot training uchun ishlatilmaydi |
| `GEMINI_FREE_KEYS` | ❌ | Bepul tier ma'lumoti mahsulotni yaxshilash uchun ishlatilishi mumkin |
| `GEMINI_PAID_KEYS` | ⚙️ | `GEMINI_PAID_ENABLED=true` bo'lgandan keyin |
| `LOCAL_VLM_URL` | ✅ | Ma'lumot infratuzilmangizdan chiqmaydi |

Bepul kalitlarning to'g'ri ishlatilishi — `training/00_synthetic_data.ipynb`
chiqargan **sintetik** dataset'da prompt sozlash. Bu real ish: kvotani
cheksiz sarflaysiz va real hujjat bilan tajriba qilish xavfi yo'q.

Bir loyiha ichidagi bir necha kalit bitta kvotani bo'lishadi, shuning uchun
ular orasida aylanish hech narsa bermaydi. Kalit pool'ining maqsadi —
**provayderlar orasida** ishonchlilik (biri uzilsa ikkinchisi ishlaydi).

## Narx

L2 asosiy, L3 ~10% bo'lganda 1000 hujjat oyiga taxminan $1–7 turadi
(model tanloviga qarab). Narxlar va model nomlari konfiguratsiyada saqlanadi,
kodda emas — provayderlar model qatorini tez-tez almashtiradi.

## ⚠️ Ishga tushirishdan oldin

`docs/LEGAL.md` ni o'qing. O'zbekiston fuqarolarining shaxsga doir
ma'lumotlari mamlakat hududidagi serverlarda saqlanishi talab qilinadi.
Render, Vercel va chet el LLM provayderlari bu talabni qondirmaydi.
`infra/render.yaml` demo va test uchun; ishlab chiqarish uchun
`infra/onprem/` yoki mahalliy hosting kerak. Men yurist emasman — bu savolni
yurist bilan hal qiling.
